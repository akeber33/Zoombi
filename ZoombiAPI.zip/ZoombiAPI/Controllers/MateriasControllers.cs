using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using ZoombiAPI.Data;
using ZoombiAPI.Models;

namespace Zoombi.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class MateriasController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public MateriasController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Materia>>> GetMaterias()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return await _context.Materias
                .Include(m => m.Professor)
                .Include(m => m.Aulas)
                .Include(m => m.Trabalhos)
                .Where(m => m.UsuarioId == userId)
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Materia>> GetMateria(int id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var materia = await _context.Materias
                .Include(m => m.Professor)
                .Include(m => m.Aulas)
                .Include(m => m.Trabalhos)
                .FirstOrDefaultAsync(m => m.Id == id && m.UsuarioId == userId);

            if (materia == null) return NotFound();
            return materia;
        }

        [HttpPost]
        public async Task<ActionResult<Materia>> CreateMateria(Materia materia)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            materia.UsuarioId = userId!;

            _context.Materias.Add(materia);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetMateria), new { id = materia.Id }, materia);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateMateria(int id, Materia materia)
        {
            if (id != materia.Id) return BadRequest();

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var existente = await _context.Materias.FindAsync(id);

            if (existente == null || existente.UsuarioId != userId)
                return NotFound();

            existente.Nome = materia.Nome;
            existente.Cor = materia.Cor;
            existente.ProfessorId = materia.ProfessorId;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMateria(int id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var materia = await _context.Materias
                .FirstOrDefaultAsync(m => m.Id == id && m.UsuarioId == userId);

            if (materia == null) return NotFound();

            _context.Materias.Remove(materia);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}