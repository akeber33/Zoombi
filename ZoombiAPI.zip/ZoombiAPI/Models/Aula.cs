namespace ZoombiAPI.Models
{
    public class Aula
    {
        public int Id { get; set; }
        public int MateriaId { get; set; }
        public DateTime DataAula { get; set; }
        public bool Presente { get; set; } = false;
        public string? Observacoes { get; set; }
        
        // Relacionamentos
        public virtual Materia Materia { get; set; } = null!;
    }
}